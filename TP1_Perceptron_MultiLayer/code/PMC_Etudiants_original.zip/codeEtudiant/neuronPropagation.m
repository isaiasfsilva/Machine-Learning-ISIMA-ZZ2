%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Propagation d'un exemple dans le perceptron au travers d'un neurone.
% En entr�e :
%   neuron : d�finition du neurone
%   exemple : exemple pr�sent� 

% En sortie :
%   output  : Valeur pr�dire par le perceptron

% Attention : � l'entr�e doit �tre ajout�e une entr�e suppl�mentaire mise � 1 
% correspondant au biais  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function output = neuron_propagation (neuron , exemple)

output= 
end